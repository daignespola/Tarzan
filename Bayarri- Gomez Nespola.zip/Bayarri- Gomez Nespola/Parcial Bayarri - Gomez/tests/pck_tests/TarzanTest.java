package pck_tests;

import org.junit.Test;

import pck_tarzan.Tarzan;

public class TarzanTest {
	@Test
	public void testCaso4(){
		Tarzan jane = new Tarzan(".\\Preparacion de la Prueba\\Casos de Prueba\\Entrada\\Una ruta.in");
		jane.resolver();
	}
	
}
