package pck_tarzan;

public class Arbol {
	int nro;
	int x;
	int y;
	public Arbol(int nro, int x, int y){
		this.nro=nro;
		this.x=x;
		this.y=y;
	}
	public Arbol(Arbol arbol){
		this.nro=arbol.nro;
		this.x=arbol.x;
		this.y=arbol.y;
	}
	public int getNro() {
		return nro;
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	
}
