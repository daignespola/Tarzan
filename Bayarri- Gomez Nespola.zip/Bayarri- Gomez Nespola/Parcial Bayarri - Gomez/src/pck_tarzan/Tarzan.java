package pck_tarzan;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

public class Tarzan {
	List<Arbol> listaArboles;
	Arbol arbolInicial;
	Arbol arbolFinal;
	int cantArboles;
	List<Arista> listaAristas;
	boolean [] visto;
	
	public Tarzan(String path){
		Scanner sc = null;
		listaArboles = new ArrayList<Arbol>();
		try{
			 sc = new Scanner(new File(path));
			 int i=0;
			 while(sc.hasNextInt()){
				 if(listaArboles.isEmpty()){
					 arbolInicial = new Arbol(i,sc.nextInt(),sc.nextInt());
					 listaArboles.add(arbolInicial);
					 i++;
				 }
				 else{
					 listaArboles.add(new Arbol(i,sc.nextInt(),sc.nextInt()));
					 i++;
				 }
			 }
			 cantArboles = listaArboles.size();
			 if(cantArboles>0)
				 arbolFinal = listaArboles.get(cantArboles-1);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			sc.close();
		}
	}
	
	public List<String> resolver(){
		List<String> resultado = new ArrayList<String>();
		listaAristas = new ArrayList<Arista>();
		List<Integer> listaSolucion = new ArrayList<Integer>();
		
		if(cantArboles == 1){
			resultado.add("NO HAY RUTA");
		}
		else{
			Arbol[] vecArboles = new Arbol[cantArboles];
			int k=0;
			visto = new boolean[cantArboles];
			for (Arbol arbol : listaArboles) {
				vecArboles[k] = new Arbol(arbol);
				visto[k]=false;
				k++;
			}
			for (int i = 0; i < vecArboles.length; i++) {
				for (int j = i; j < vecArboles.length; j++) {
					if(vecArboles[i].nro!= vecArboles[j].nro &&Math.sqrt(Math.pow(vecArboles[j].x-vecArboles[i].x, 2)+Math.pow(vecArboles[j].y-vecArboles[i].y, 2)) <50){
						listaAristas.add(new Arista(vecArboles[i].nro,vecArboles[j].nro,Math.sqrt(Math.pow(vecArboles[j].x-vecArboles[i].x, 2)+Math.pow(vecArboles[j].y-vecArboles[i].y, 2))));
					}
				}
			}
			
			listaSolucion.add(arbolInicial.nro);
			visto[arbolInicial.nro]=true;
			
			int nodoNro = arbolInicial.nro;
			
			while(listaSolucion.get(listaSolucion.size()-1)!= arbolFinal.nro){
				int a = obtenerAristaCostoMin(nodoNro);
				listaSolucion.add(a);
				nodoNro = a;
			}
		}
		return resultado;
	}
	
	public int obtenerAristaCostoMin(int nodo){
		int i= arbolInicial.nro;
		double min = 999;
		for (Arista arista : listaAristas) {
			if(arista.costo<min && arista.nodoOrigen == nodo&&!visto[arista.nodoDestino]){
				visto[arista.nodoDestino]= true;
				min=arista.costo;
				i =arista.nodoDestino;
			}
		}
		return i;
	}
	
	public void generarArchivo(List<String> resultado, String path){
		PrintWriter pw = null;
		FileWriter fw = null;
		try{
			fw = new FileWriter(path);
			pw = new PrintWriter(fw);
			for (String linea : resultado) {
				pw.println(linea);
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try {
				fw.close();
				pw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
