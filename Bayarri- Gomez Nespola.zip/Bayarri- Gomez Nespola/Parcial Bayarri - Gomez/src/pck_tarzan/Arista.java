package pck_tarzan;

public class Arista {
	int nodoOrigen;
	int nodoDestino;
	double costo;
	
	public Arista(int orig, int dest, double costo){
		this.nodoOrigen=orig;
		this.nodoDestino=dest;
		this.costo = costo;
	}
}
